# Inventory Management System

It is a web application that was developed for the Institute of Information Technology (IIT), 
University of Dhaka. It was developed to provide a completely automated system through which users could 
check and track the available inventories at the store of IIT, order for new inventories, etc.
